

from django.shortcuts import render, redirect
from .forms import ContactForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import  TemplateView
from django.shortcuts import render
from .forms import ContactForm  # ensure you've imported your ContactForm

from django.contrib.auth.decorators import login_required
from django.contrib import messages


@login_required
def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('my_app/home')
    else:
        form = ContactForm()
    return render(request, 'my_app/home.html', {'form': form})





class HomeView(LoginRequiredMixin, TemplateView):
    template_name = 'my_app/home.html'  # your template name

    # GET method
    def get(self, request, *args, **kwargs):
        form = ContactForm()  # instantiate a new, empty form
        return self.render_to_response({'form': form})

    # POST method
    def post(self, request, *args, **kwargs):
        form = ContactForm(request.POST)  
        if form.is_valid():
            form.save()  
            messages.success(request, 'Form submission successful')
            return redirect('my_app/home.html')  
        return self.render_to_response({'form': form})




