
from django.urls import include, path



from my_app.views import HomeView

urlpatterns = [

    path('', HomeView.as_view(), name='home'),

]


